<title>UMKM Online Shop</title>

<?php $__env->startSection('nav'); ?>
                    <li class="active"><a href="/">Home</a></li>
                    <li><a href="/keranjang">Keranjang 
                        <?php if(Route::has('login')): ?>
                            <?php if(auth()->guard()->check()): ?>
                                <span>(<?php echo e($keranjang = \App\Models\Detail_pesanan::where('status','=','keranjang')->where('id_user','=',auth()->user()->id)->count()); ?>)</span>
                            <?php else: ?>
                                <span>(0)</span>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                    </a></li>
                    <li><a href="/pesanan">Pesanan</a></li>
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <li><a href="/akun">Akun</a></li>
                            <li><a href="/logout">Logout</a></li>
                        <?php else: ?>
                            <li><a href="/login"></i>Login</a></li>
                            <li><a href="/daftar"></i>Register</a></li>
                        <?php endif; ?>
                    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="products-catagories-area clearfix">
            <?php if(Session::has('login')): ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <strong>Anda berhasil Login!</strong> Selamat datang dan selamat berbelanja <?php echo e(auth()->user()->nama); ?>

            </div>
            <?php elseif(Session::has('keranjang')): ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <strong>Berhasil menambah ke keranjang</strong> Silahkan cek keranjang anda
            </div>
            <?php elseif(Session::has('pesanan')): ?>
            <div class="alert alert-success">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <strong>Pesanan Berhasil dibuat</strong> lakukan pembayaran agar segera diproses.
            </div>   
            <?php endif; ?>
            
            <div class="amado-pro-catagory clearfix">

                <!-- Single Catagory -->
                <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="single-products-catagory clearfix">
                    <a href="/detail-produk/<?php echo e($p->id); ?>">
                        <img src="<?php echo e($p->img); ?>" alt="">
                        <!-- Hover Content -->
                        <div class="hover-content">
                            <div class="line"></div>
                            <p>Rp<?php echo e(number_format($p->harga,2,",",".")); ?></p>
                            <h4><?php echo e($p->nama_produk); ?></h4>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\umkm\resources\views/index.blade.php ENDPATH**/ ?>