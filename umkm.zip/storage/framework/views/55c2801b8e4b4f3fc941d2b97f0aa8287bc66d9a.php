<title>Lakukan Pembayaran</title>
<?php $__env->startSection('nav'); ?>
                    <li><a href="/">Home</a></li>
                    <li><a href="/keranjang">Keranjang 
                        <?php if(Route::has('login')): ?>
                            <?php if(auth()->guard()->check()): ?>
                                <span>(<?php echo e($cart = \App\Models\Detail_pesanan::where('status','=','keranjang')->where('id_user','=',auth()->user()->id)->count()); ?>)</span>
                            <?php else: ?>
                                <span>(0)</span>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                    </a></li>
                    <li><a href="/pesanan">Pesanan</a></li>
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <li><a href="/akun">Akun</a></li>
                            <li><a href="/logout">Logout</a></li>
                        <?php else: ?>
                            <li><a href="/login"></i>Login</a></li>
                            <li><a href="/daftar"></i>Daftar</a></li>
                        <?php endif; ?>
                    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="cart-table-area section-padding-100">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-lg-12">
                        <div class="cart-summary">
                            <h4>Pesanan <b><?php echo e($pesanan->kode_pesanan); ?></b></h4>
                            <hr>
                            <h6>Silahkan lakukan pembayaran ke salah satu rekening berikut:</h6>
                            <ul class="summary-table">
                                <li><h5>Bank Mandiri | 100-001-22-07 a/n Toko Jersey Indo</h5></li>
                                <li><h5>Bank BNI | 100-001-22-07 a/n Toko Jersey Indo</h5></li>
                                <li><h5>Bank BRI | 100-001-22-07 a/n Toko Jersey Indo</h5></li>
                            </ul>
                            <form action="/upload-bayar/<?php echo e($pesanan->id); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <hr>
                                <h5>Silahkan transfer sesuai total belanja anda senilai <b>Rp<?php echo e(number_format($pesanan->total_harga+$pesanan->ongkir,2,",",".")); ?></b> </h5>
                                <input type="file" name="bukti" class="mt-50">
                                <div class="cart-btn mt-50">
                                    <input type="submit" class="btn amado-btn w-100" value="Upload Bukti Transfer">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\umkm\resources\views/norek.blade.php ENDPATH**/ ?>