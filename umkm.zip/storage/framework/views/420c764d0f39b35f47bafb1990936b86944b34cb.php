<title>Checkout</title>
<?php $__env->startSection('nav'); ?>
                    <li><a href="/">Home</a></li>
                    <li><a href="/keranjang">Keranjang 
                        <?php if(Route::has('login')): ?>
                            <?php if(auth()->guard()->check()): ?>
                                <span>(<?php echo e($cart = \App\Models\Detail_pesanan::where('status','=','keranjang')->where('id_user','=',auth()->user()->id)->count()); ?>)</span>
                            <?php else: ?>
                                <span>(0)</span>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                    </a></li>
                    <li><a href="/pesanan">Pesanan</a></li>
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <li><a href="/akun">Akun</a></li>
                            <li><a href="/logout">Logout</a></li>
                        <?php else: ?>
                            <li><a href="/login"></i>Login</a></li>
                            <li><a href="/daftar"></i>Daftar</a></li>
                        <?php endif; ?>
                    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="cart-table-area section-padding-100">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-lg-12">
                        <div class="cart-title mt-50">
                            <h2>Rincian Pesanan</h2>
                        </div>

                        <div class="cart-table clearfix">
                            <table class="table table-responsive">
                                <thead>
                                    <tr>
                                        <th>Gambar</th>
                                        <th>Produk</th>
                                        <th>Harga</th>
                                        <th>Jumlah</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $keranjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="cart_product_img">
                                            <a href="#"><img src="<?php echo e($k->produk->img); ?>" alt="Product"></a>
                                        </td>
                                        <td class="cart_product_desc">
                                            <h5><?php echo e($k->produk->nama_produk); ?></h5>
                                        </td>
                                        <td class="price">
                                            <span>Rp<?php echo e(number_format($k->produk->harga,2,",",".")); ?></span>
                                        </td>
                                        <td class="qty">
                                            <div class="qty-btn d-flex">
                                                <p>Qty</p>
                                                <div class="quantity">
                                                    
                                                    <input type="number" class="qty-text" id="qty" step="1" min="1" max="300" name="quantity" value="<?php echo e($k->qty); ?>">
                                                    
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-12">
                        <div class="cart-summary">
                            <h5>Rincian Penerima <a class="btn btn-sm btn-warning float-right" href="/edit-profile"><i class="fa fa-edit"></i> Ubah Data</a></h5>
                            <ul class="summary-table">
                                <?php
                                    $harga = 0;
                                    foreach ($keranjang as $k) {
                                        $harga = $harga + ($k->produk->harga*$k->qty);
                                    }
                                ?>
                                <li><span>Nama Penerima :</span><span><?php echo e(auth()->user()->nama); ?></span></li>
                                <li><span>alamat        :</span> <span><?php echo e(auth()->user()->alamat); ?></span></li>
                                <li><span>Kode Pos      :</span> <span><?php echo e(auth()->user()->kode_pos); ?></span></li>
                                <li><span>No. HP        :</span> <span><?php echo e(auth()->user()->no_hp); ?></span></li>
                                
                                <form action="/bayar" method="POST">
                                    <?php echo csrf_field(); ?>
                                <li><span>Catatan       :</span> <input name="catatan" class="form-control col-lg-3" type="text" placeholder="(opsional)"></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-12">
                        <div class="cart-summary">
                            <h5>Total Pembayaran</h5>
                            <ul class="summary-table">
                                <?php
                                    $harga = 0;
                                    foreach ($keranjang as $k) {
                                        $harga = $harga + ($k->produk->harga*$k->qty);
                                    }
                                ?>
                                <li><span>Subtotal :</span><span>Rp<?php echo e(number_format($harga,2,",",".")); ?></span></li>
                                <li><span>Ongkir :</span> <span>Rp<?php echo e(number_format(20000,2,",",".")); ?></span></li>
                                <li><span>Total :</span> <span>Rp<?php echo e(number_format($harga+20000,2,",",".")); ?></span></li>
                            </ul>
                            <div class="cart-btn mt-100">
                                
                                    <input type="hidden" name="id_user" value="<?php echo e(auth()->user()->id); ?>">
                                    <input type="hidden" name="total_harga" value="<?php echo e($harga); ?>">
                                    <input type="hidden" name="ongkir" value="20000">

                                    <button type="submit" class="btn amado-btn w-100">Bayar</button> 
                                </form>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\umkm\resources\views/checkout.blade.php ENDPATH**/ ?>