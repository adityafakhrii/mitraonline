<title>Detail Produk</title>
<?php $__env->startSection('nav'); ?>
                    <li class="active"><a href="/">Home</a></li>
                    <li><a href="/keranjang">Keranjang 
                        <?php if(Route::has('login')): ?>
                            <?php if(auth()->guard()->check()): ?>
                                <span>(<?php echo e($keranjang = \App\Models\Detail_pesanan::where('status','=','keranjang')->where('id_user','=',auth()->user()->id)->count()); ?>)</span>
                            <?php else: ?>
                                <span>(0)</span>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                    </a></li>
                    <li><a href="/pesanan">Pesanan</a></li>
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <li><a href="/akun">Akun</a></li>
                            <li><a href="/logout">Logout</a></li>
                        <?php else: ?>
                            <li><a href="/login"></i>Login</a></li>
                            <li><a href="/daftar"></i>Register</a></li>
                        <?php endif; ?>
                    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <!-- Product Details Area Start -->
        <div class="single-product-area section-padding-100 clearfix">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-12">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mt-50">
                                <li class="breadcrumb-item"><a href="/">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><?php echo e($produk->nama_produk); ?></li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 col-lg-7">
                        <div class="single_product_thumb">
                            <div id="product_details_slider" class="carousel slide" data-ride="carousel">
                                    <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        <a class="gallery_img" href="<?php echo e($produk->img); ?>">
                                            <img class="d-block w-100" src="<?php echo e($produk->img); ?>" alt="">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-5">
                        <div class="single_product_desc">
                            <!-- Product Meta Data -->
                            <div class="product-meta-data">
                                <div class="line"></div>
                                <p class="product-price">Rp<?php echo e(number_format($produk->harga,2,",",".")); ?></p>
                                <a href="product-details.html">
                                    <h6><?php echo e($produk->nama_produk); ?></h6>
                                </a>
                                <!-- Ratings & Review -->
                                <div class="ratings-review mb-15 d-flex align-items-center justify-content-between">
                                    <div class="ratings">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                    </div>
                                </div>
                                <!-- Avaiable -->
                                <?php if($produk->status == 'Tersedia'): ?>
                                    <p class="avaibility"><i class="fa fa-circle"></i> Tersedia | sisa <?php echo e($produk->stok); ?> pcs</p>
                                <?php else: ?>
                                    <p class="avaibility-out"><i class="fa fa-circle"></i> Habis</p>
                                <?php endif; ?>
                            </div>

                            <div class="short_overview my-5">
                                <p><?php echo e($produk->deskripsi); ?></p>
                            </div>

                            <!-- Add to Cart Form -->
                            <form action="/postkeranjang/<?php echo e($produk->id); ?>" class="cart clearfix" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="cart-btn d-flex mb-50">
                                    <p>Qty</p>
                                    <div class="quantity">
                                        <span class="qty-minus" onclick="var effect = document.getElementById('qty'); var qty = effect.value; if( !isNaN( qty ) &amp;&amp; qty &gt; 1 ) effect.value--;return false;"><i class="fa fa-caret-down" aria-hidden="true"></i></span>
                                        <input type="number" class="qty-text" id="qty" step="1" min="1" max="300" name="qty" value="1">
                                        <span class="qty-plus" onclick="var effect = document.getElementById('qty'); var qty = effect.value; if( !isNaN( qty )) effect.value++;return false;"><i class="fa fa-caret-up" aria-hidden="true"></i></span>
                                        <input type="hidden" name="id_produk" value="<?php echo e($produk->id); ?>">
                                        <?php if(auth()->guard()->check()): ?>
                                        <input type="hidden" name="id_user" value="<?php echo e(auth()->user()->id); ?>">
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php if($produk->status == 'Tersedia'): ?>
                                <button type="submit" name="addtocart" value="5" class="btn amado-btn">Tambah ke Keranjang</button>
                                <?php else: ?>
                                <button type="submit" name="addtocart" value="5" class="btn amado-btn-disabled" disabled="">Stok Habis</button>
                                <?php endif; ?>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Product Details Area End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\umkm\resources\views/product-details.blade.php ENDPATH**/ ?>