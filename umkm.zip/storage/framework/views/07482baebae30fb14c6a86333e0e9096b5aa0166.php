<title>Keranjang</title>
<?php $__env->startSection('nav'); ?>
                    <li><a href="/">Home</a></li>
                    <li class="active"><a href="/keranjang">Keranjang 
                        <?php if(Route::has('login')): ?>
                            <?php if(auth()->guard()->check()): ?>
                                <span>(<?php echo e($cart = \App\Models\Detail_pesanan::where('status','=','keranjang')->where('id_user','=',auth()->user()->id)->count()); ?>)</span>
                            <?php else: ?>
                                <span>(0)</span>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                    </a></li>
                    <li><a href="/pesanan">Pesanan</a></li>
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <li><a href="/akun">Akun</a></li>
                            <li><a href="/logout">Logout</a></li>
                        <?php else: ?>
                            <li><a href="/login"></i>Login</a></li>
                            <li><a href="/daftar"></i>Daftar</a></li>
                        <?php endif; ?>
                    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="cart-table-area section-padding-100">
            <div class="container-fluid">
                    
                <div class="row">
                    <div class="col-12 col-lg-12">
                        <div class="cart-title mt-50">
                            <h2>Keranjang Belanja</h2>
                        </div>
                        <?php if($keranjang->count() != 0): ?>
                        <div class="cart-table clearfix">
                            <table class="table table-responsive">
                                <thead>
                                    <tr>
                                        <th>Gambar</th>
                                        <th>Produk</th>
                                        <th>Harga</th>
                                        <th>Jumlah</th>
                                        <th>Total</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php
                                        $harga = 0;
                                        foreach ($keranjang as $k) {
                                            $harga = $harga + ($k->produk->harga*$k->qty);
                                        }
                                    ?>
                                    <?php $__currentLoopData = $keranjang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="cart_product_img" >
                                            <a href="/detail-produk/<?php echo e($k->produk->id); ?>"><img src="<?php echo e($k->produk->img); ?>" alt="Product" width="90"></a>
                                        </td>
                                        <td class="cart_product_desc">
                                            <a href="/detail-produk/<?php echo e($k->produk->id); ?>"><h5><?php echo e($k->produk->nama_produk); ?></h5></a>
                                        </td>
                                        <td class="price">
                                            <span>Rp<?php echo e(number_format($k->produk->harga,2,",",".")); ?></span>
                                        </td>
                                        <td class="qty">
                                            <form action="/keranjang/edit/<?php echo e($k->id); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="qty-btn d-flex">
                                                <p>Qty</p>
                                                <div class="quantity">
                                                    
                                                    <input type="number" class="qty-text" id="qty" step="1" min="1" max="999" name="qty" value="<?php echo e($k->qty); ?>">
                                                    
                                                </div>
                                            </div>
                                        </td>
                                        <td class="price">
                                            <span>Rp <?php echo e(number_format($k->produk->harga*$k->qty)); ?></span>
                                        </td>
                                        <td>
                                            <button type="submit" class="btn btn-sm btn-warning">Ubah stok</button>
                                            </form>
                                            <a class="btn btn-sm btn-danger" href="/keranjang/hapus/<?php echo e($k->id); ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-12 col-lg-12">
                        <div class="cart-summary">
                            <ul class="summary-table">
                                <li><h4>Total Belanja :</h4><h4>Rp<?php echo e(number_format($harga,2,",",".")); ?></h4></li>
                            </ul>
                            <div class="cart-btn mt-100">
                                <a href="/checkout" class="btn amado-btn w-100">Checkout</a>
                            </div>
                            <?php else: ?>
                                <h4 class="text-center">Keranjang Kosong</h4>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\umkm\resources\views/cart.blade.php ENDPATH**/ ?>