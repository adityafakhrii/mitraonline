<title>Edit Akun - <?php echo e(auth()->user()->nama); ?></title>
<?php $__env->startSection('nav'); ?>
                    <li><a href="/">Home</a></li>
                    <li><a href="/keranjang">Keranjang 
                        <?php if(Route::has('login')): ?>
                            <?php if(auth()->guard()->check()): ?>
                                <span>(<?php echo e($cart = \App\Models\Detail_pesanan::where('status','=','keranjang')->where('id_user','=',auth()->user()->id)->count()); ?>)</span>
                            <?php else: ?>
                                <span>(0)</span>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                    </a></li>
                    <li><a href="/pesanan">Pesanan</a></li>
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                            <li><a href="/akun">Akun</a></li>
                            <li><a href="/logout">Logout</a></li>
                        <?php else: ?>
                            <li><a href="/login"></i>Login</a></li>
                            <li><a href="/daftar"></i>Daftar</a></li>
                        <?php endif; ?>
                    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        <div class="cart-table-area section-padding-100">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 col-lg-12">
                        <div class="checkout_details_area mt-50 clearfix">

                            <div class="cart-title">
                                <h2>Ubah Profil Akun<a class="btn btn-sm btn-outline-secondary float-right" href="/akun"><i class="fa fa-angle-left"></i> Kembali</a></h2>
                            </div>

                            <form action="/akun/update/<?php echo e($user->id); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-12">
                                        <p>Profil Pengguna</p>
                                    </div>
                                    <div class="col-12 mb-3">
                                        <input type="text" class="form-control" id="name" name="nama" placeholder="Nama Lengkap" value="<?php echo e(auth()->user()->nama); ?>" required>
                                    </div>
                                    <div class="col-12 mb-3">
                                        <input type="text" class="form-control" id="street_address" name="alamat" placeholder="Alamat Lengkap" value="<?php echo e(auth()->user()->alamat); ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <input type="text" class="form-control" id="zipCode" name="kode_pos" placeholder="Kode Pos" value="<?php echo e(auth()->user()->kode_pos); ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-4">
                                        <input type="number" class="form-control" id="phone_number" name="no_hp" min="0" value="<?php echo e(auth()->user()->no_hp); ?>" placeholder="No. Telepon" required>
                                    </div>
                                    <div class="col-12 mb-3">
                                        <input type="email" class="form-control" id="email" name="email" placeholder="Email" value="<?php echo e(auth()->user()->email); ?>" required>
                                    </div>
                                    <div class="col-md-8 mb-4">
                                        
                                    </div>
                                    <div class="col-md-4 mb-4">
                                        <div class="cart-btn mt-4">
                                            <button type="submit" class="btn amado-btn w-100">Ubah</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\umkm\resources\views/edit-akun.blade.php ENDPATH**/ ?>